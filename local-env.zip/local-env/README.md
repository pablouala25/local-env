# 🚀 **Comandos Principales**

### **🔄 Operaciones Básicas**
```bash
make up      # Levantar servicios (sin compilar)
make down    # Parar servicios  
make reset   # Reiniciar servicios (down + up)
make status  # Ver estado de servicios
```

### **🏗️ Operaciones de Construcción**
```bash
make build   # Compilar + levantar todo
make clean   # Limpiar todo (volúmenes, binarios)
make rebuild # Limpiar y construir desde cero
```

### **🛠️ Operaciones de Desarrollo**
```bash
make fmt            # Formatear código Go
make generate-mocks # Regenerar mocks
make bin-build      # Solo compilar Lambda
make create-tables  # Solo crear tablas DynamoDB
```

---

# 🔐 Ambiente Local - Lambda Reauth Rules

Este proyecto emula un entorno completo de AWS en local para desarrollar, testear y depurar la **Lambda de Reauth Rules** usando **Docker Compose**, **AWS SAM CLI** y **Go**.

---

## 📋 Contenido

* ✅ **Requisitos**
* 🏗️ **Estructura del proyecto**
* 🛠️ **Guía de uso rápido**
* 🎯 **Comandos y cuándo usarlos**
* 🧪 **Probar la API**
* ⚙️ **Servicios y arquitectura**
* 🐛 **Solución de problemas**
* 📚 **Variables de entorno**

---

## ✅ Requisitos

Asegurate de tener instalados:

* [Docker](https://www.docker.com/) + Docker Compose v2
* [Go](https://golang.org/) 1.23 o superior
* [AWS SAM CLI](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html)
* [AWS CLI](https://aws.amazon.com/cli/) (opcional, para interactuar con DynamoDB local)

---

## 🏗️ Estructura del Proyecto

```text
local-env/
├── bin/                 # Binarios compilados (bootstrap)
├── dynamodb_data/       # Datos persistentes de DynamoDB Local
├── localstack_init/     # Scripts de inicialización de LocalStack
├── .env                 # Variables de entorno
├── docker-compose.yml   # Servicios Docker
├── Dockerfile.sam       # Imagen personalizada para SAM CLI
├── Makefile             # Comandos útiles
├── template.yml         # SAM template (infraestructura)
└── README.md            # Esta documentación

Código fuente (directorio padre):
../cmd/                  # Código fuente Go (main.go)
../internal/             # Bounded contexts (check, update, validate)
../pkg/                  # Librerías compartidas
```

---

## 🛠️ Guía de Uso Rápido

### 🚀 **Primera Vez o Cambios en Código**

```bash
cd local-env
make build
```

Este comando hace **todo** en secuencia:
1. ✅ Prepara el directorio `bin/`
2. ✅ Compila la Lambda Go → `bin/bootstrap`
3. ✅ Levanta contenedores Docker
4. ✅ Crea tabla DynamoDB (reauth-rules-local)
5. ✅ Inicia SAM Local API

**Tiempo estimado:** ~1-2 minutos la primera vez

---

### ⚡ **Solo Levantar Servicios (sin compilar)**

```bash
cd local-env
make up
```

Útil cuando:
- Ya compilaste anteriormente
- No hiciste cambios en el código Go
- Solo quieres levantar el ambiente rápido

**Tiempo estimado:** ~30 segundos

---

### 🔄 **Reiniciar Servicios**

```bash
cd local-env
make reset
```

Hace: `down` + `up`
- Preserva binarios compilados
- Preserva datos en DynamoDB
- Reinicia contenedores

**Tiempo estimado:** ~30 segundos

---

### 🧹 **Limpieza Completa**

```bash
cd local-env
make clean
```

Elimina:
- ✅ Contenedores y volúmenes Docker
- ✅ Binarios compilados (`bin/`)
- ✅ Datos de DynamoDB

**Uso:** Cuando hay problemas persistentes o quieres empezar desde cero

---

### 🆕 **Reconstrucción Completa**

```bash
cd local-env
make rebuild
```

Hace: `clean` + `build`
- Limpia todo
- Compila desde cero
- Levanta ambiente nuevo

**Tiempo estimado:** ~2-3 minutos

---

## 🎯 **Cuándo Usar Cada Comando**

| Comando | Compila | Levanta | Limpia | Uso |
|---------|---------|---------|--------|-----|
| `make build` | ✅ | ✅ | ❌ | Primera vez o cambios en código Go |
| `make up` | ❌ | ✅ | ❌ | Levantar servicios (ya compilaste) |
| `make reset` | ❌ | ✅ | ❌ | Reiniciar servicios rápido |
| `make rebuild` | ✅ | ✅ | ✅ | Problemas persistentes |
| `make down` | ❌ | ❌ | ❌ | Solo parar servicios |
| `make clean` | ❌ | ❌ | ✅ | Limpiar todo |

### **Flujo de Trabajo Típico**

```bash
# 1️⃣ Primer día o cambios importantes
make build

# 2️⃣ Siguiente día (sin cambios)
make up

# 3️⃣ Cambios en código Go
make bin-build    # Solo compilar
make reset        # Reiniciar servicios

# 4️⃣ Problemas extraños
make rebuild      # Empezar desde cero

# 5️⃣ Fin del día
make down
```

---

## 🧪 **Probar la API**

Una vez levantado el ambiente, los servicios están disponibles en:

### **🌐 Servicios Disponibles**

| Servicio | URL | Descripción |
|----------|-----|-------------|
| **API Gateway** | http://localhost:3000 | Endpoints de la Lambda |
| **DynamoDB Admin** | http://localhost:8001 | UI para ver/editar datos |
| **DynamoDB Local** | http://localhost:8000 | Endpoint de DynamoDB |
| **LocalStack** | http://localhost:4566 | Servicios AWS emulados |

### **📝 Ejemplos de Requests**

#### **Crear Regla**

```bash
curl -X POST http://localhost:3000/api/v1/rules \
  -H "Content-Type: application/json" \
  -d '{
    "id": "rule-001",
    "initiative_id": "transfer",
    "category": "amount",
    "description": "Require reauth for transfers above $10000",
    "rule": "amount > 10000"
  }'
```

**Respuesta esperada:**
```json
{
  "id": "rule-001",
  "initiative_id": "transfer",
  "category": "amount",
  "description": "Require reauth for transfers above $10000",
  "rule": "amount > 10000"
}
```

#### **Obtener Regla por ID**

```bash
curl -X GET http://localhost:3000/api/v1/rules/rule-001
```

#### **Listar Todas las Reglas**

```bash
curl -X GET "http://localhost:3000/api/v1/rules?limit=10"
```

#### **Listar Reglas por Iniciativa**

```bash
curl -X GET "http://localhost:3000/api/v1/rules/by-initiative?initiative_id=transfer"
```

#### **Actualizar Regla**

```bash
curl -X PUT http://localhost:3000/api/v1/rules/rule-001 \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Updated description",
    "rule": "amount > 15000"
  }'
```

#### **Eliminar Regla (Soft Delete)**

```bash
curl -X DELETE http://localhost:3000/api/v1/rules/rule-001
```

#### **Restaurar Regla Eliminada**

```bash
curl -X POST http://localhost:3000/api/v1/rules/rule-001/restore
```

#### **Ver Estado del Ambiente**

```bash
# Ver tablas en DynamoDB
aws dynamodb list-tables \
  --endpoint-url http://localhost:8000 \
  --region us-east-1

# Ver items en Rules
aws dynamodb scan \
  --table-name reauth-rules-local \
  --endpoint-url http://localhost:8000 \
  --region us-east-1
```

---

## ⚙️ **Arquitectura y Servicios**

### **🧩 Diagrama de Arquitectura Local**

```text
[Curl / Postman]
       │
       ▼
┌──────────────┐
│  sam-local   │  → API Gateway local (Puerto 3000)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│lambda-go-dev │  → Lambda Go compilada (bootstrap)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│dynamodb-local│  → DynamoDB (Puerto 8000)
└──────────────┘
       ↑
       │
┌──────────────┐
│dynamodb-admin│  → UI DynamoDB (Puerto 8001)
└──────────────┘

+ Opcional:
┌──────────────┐
│ localstack   │  → SQS, SNS, S3, etc. (Puerto 4566)
└──────────────┘
```

### **📦 Contenedores y Servicios**

#### **1. 🗄️ dynamodb-local**
- **Imagen:** `public.ecr.aws/aws-dynamodb-local/aws-dynamodb-local:2.6.1`
- **Puerto:** `8000`
- **Función:** Base de datos local para desarrollo
- **Persistencia:** Volumen `dynamodb_data/`
- **Healthcheck:** Verifica disponibilidad cada 5s

**Tablas creadas automáticamente:**
- `reauth-rules-local` - Reglas de reautenticación
  - PK: `rule_id`
  - GSI 1: `AllItemsIndex` (por `all_pk`)
  - GSI 2: `InitiativeIDIndex` (por `initiative_id`)

#### **2. 📊 dynamodb-admin**
- **Imagen:** `aaronshaf/dynamodb-admin:5.1.3`
- **Puerto:** `8001`
- **Función:** UI web para gestionar DynamoDB
- **Acceso:** http://localhost:8001

#### **3. 🧠 lambda-go-dev**
- **Imagen:** `public.ecr.aws/lambda/provided:al2023.2025.08.07.12`
- **Puerto:** `9000` (interno)
- **Función:** Runtime Lambda con el binario Go
- **Binario:** Monta `bin/bootstrap` desde local

**Variables de entorno:**
```env
AWS_REGION=us-east-1
DYNAMODB_ENDPOINT=http://dynamodb-local:8000
RULESDB_TABLE_NAME=reauth-rules-local
DYNAMODB_TABLE_NAME=reauth-rules-local
DDB_ALL_ITEMS_INDEX=AllItemsIndex
DDB_RULES_BY_INITIATIVE_INDEX=InitiativeIDIndex
```

#### **4. 🔁 localstack**
- **Imagen:** `localstack/localstack:4.7.0`
- **Puerto:** `4566`
- **Función:** Emula servicios AWS (SQS, SNS, S3, etc.)
- **Persistencia:** Volumen `localstack_state`

#### **5. 🌐 sam-local**
- **Imagen:** Custom (Dockerfile.sam)
- **Puerto:** `3000`
- **Función:** Emula API Gateway
- **Comando:** `sam local start-api`
- **Config:** Lee `template.yml`

**Particularidades:**
- Monta socket Docker (`/var/run/docker.sock`)
- Monta código fuente (`../`)
- Telemetría desactivada

---

## 🔧 **Targets del Makefile**

### **Targets Principales**
```bash
make build         # Compilar + levantar todo
make up            # Levantar servicios (sin compilar)
make down          # Detener servicios
make reset         # Reiniciar (down + up)
make clean         # Limpiar todo
make rebuild       # Limpiar + construir
make status        # Ver estado de servicios
```

### **Targets de Compilación**
```bash
make prepare-bin   # Preparar directorio bin/
make bin-build     # Compilar Lambda Go
make fmt           # Formatear código
make generate-mocks # Regenerar mocks
```

### **Targets de Infraestructura**
```bash
make compose-up       # Levantar Docker Compose
make compose-rebuild  # Reconstruir contenedores
make create-tables    # Crear tablas DynamoDB
make sam-up           # Iniciar SAM (solo, sin todo)
```

### **Dependencias entre Targets**

```text
make build
  └─ prepare-bin
  └─ bin-build (requiere: prepare-bin)
  └─ compose-up (requiere: prepare-bin)
  └─ create-tables
  └─ sam-up

make up
  └─ prepare-bin
  └─ compose-up
  └─ create-tables
  └─ sam-up
```

---

## 🐛 **Solución de Problemas Comunes**

### **❌ Error: "permission denied" al compilar**

**Síntoma:**
```bash
open .../bin/bootstrap: permission denied
```

**Causa:** Docker creó el directorio `bin/` como root.

**Solución:**
```bash
sudo rm -rf bin/
make prepare-bin
make bin-build
```

O simplemente:
```bash
make rebuild
```

---

### **❌ Error: SAM no encuentra el binario**

**Síntoma:**
```bash
Error: bootstrap not found
```

**Solución:**
```bash
make bin-build
docker compose restart sam-local
```

---

### **❌ DynamoDB no responde**

**Síntoma:** Tablas no se crean o queries fallan.

**Verificar estado:**
```bash
docker compose ps
docker compose logs dynamodb-local
```

**Solución:**
```bash
# Esperar a que esté healthy
make status

# Si persiste, reiniciar
make reset
```

---

### **❌ Puerto 3000 ocupado**

**Síntoma:**
```bash
Error: Address already in use
```

**Encontrar proceso:**
```bash
lsof -ti:3000 | xargs kill
```

**O cambiar puerto en docker-compose.yml:**
```yaml
sam-local:
  ports:
    - "3001:3000"  # Cambiar 3000 a 3001
```

---

### **❌ Directorio `home/` creado incorrectamente**

**Síntoma:** Se crea `local-env/home/pablo/...`

**Causa:** Error en la ruta de compilación.

**Solución:**
```bash
rm -rf home/
make rebuild
```

---

### **❌ Contenedores no inician**

**Verificar logs:**
```bash
docker compose logs -f
```

**Verificar estado:**
```bash
make status
```

**Reiniciar todo:**
```bash
make rebuild
```

---

## 📚 **Variables de Entorno**

El archivo `.env` contiene todas las variables de configuración:

### **DynamoDB Local**
```env
DYNAMODB_PORT=8000
DYNAMODB_ENDPOINT=http://dynamodb-local:8000
DYNAMODB_DATA_PATH=/data
```

### **Tablas DynamoDB**
```env
RULESDB_TABLE_NAME=reauth-rules-local
DYNAMODB_TABLE_NAME=reauth-rules-local
RULES_TABLE_NAME=reauth-rules-local
```

### **Configuración AWS**
```env
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=dummy
AWS_SECRET_ACCESS_KEY=dummy
```

### **Networking**
```env
APP_NETWORK=app-network
```

### **LocalStack**
```env
SERVICES=apigateway,lambda,sqs
PERSISTENCE=1
LAMBDA_KEEPALIVE_MS=0
```

---

## 🧪 **Testing y Desarrollo**

### **Compilación con Debug Info**

El Makefile compila con símbolos de debug:
```bash
go build -gcflags "all=-N -l" ...
```

Esto permite:
- 🐛 Debugging con delve
- 📊 Stack traces completos
- 🔍 Mejor troubleshooting

### **Hot Reload (limitado)**

SAM detecta algunos cambios automáticamente, pero para cambios en Go:
```bash
make bin-build
# SAM detectará el nuevo binario automáticamente
```

### **Logs en Tiempo Real**

```bash
# Todos los servicios
docker compose logs -f

# Solo Lambda
docker compose logs -f lambda-go-dev

# Solo SAM
docker compose logs -f sam-local
```

---

## 📊 **Comparación de Comandos**

| Aspecto | `make build` | `make up` | `make reset` | `make rebuild` |
|---------|--------------|-----------|--------------|----------------|
| **Compila Go** | ✅ | ❌ | ❌ | ✅ |
| **Levanta Docker** | ✅ | ✅ | ✅ | ✅ |
| **Crea Tablas** | ✅ | ✅ | ✅ | ✅ |
| **Inicia SAM** | ✅ | ✅ | ✅ | ✅ |
| **Limpia Binarios** | ❌ | ❌ | ❌ | ✅ |
| **Limpia Volúmenes** | ❌ | ❌ | ❌ | ✅ |
| **Tiempo** | 🐌 1-2 min | ⚡ 30s | ⚡ 30s | 🐌 2-3 min |
| **Uso** | Cambios código | Levantar | Reiniciar | Problemas |

---

## 🚀 **Próximos Pasos**

Una vez que el ambiente esté corriendo:

1. **Explora la API** - Prueba los endpoints con curl o Postman
2. **Revisa DynamoDB Admin** - http://localhost:8001
3. **Lee el código** - Explora `../internal/check/`, `../internal/update/`, etc.
4. **Ejecuta tests** - `cd .. && go test ./...`
5. **Desarrolla features** - Cambia código, compila con `make bin-build`

---

## 📝 **Notas Importantes**

### **Persistencia de Datos**

- ✅ **DynamoDB:** Datos persisten en `dynamodb_data/`
- ✅ **LocalStack:** Estado persiste en volumen Docker
- ❌ **Lambda:** Binario se recompila en cada cambio

Para limpiar datos:
```bash
make clean  # Limpia todo
```

Para preservar datos:
```bash
make reset  # Solo reinicia servicios
```

### **Performance**

Primera vez: ~1-2 minutos (descarga imágenes)
Siguientes veces: ~30 segundos

### **Arquitectura Hexagonal**

El proyecto sigue arquitectura hexagonal:
- `usecase/` - Capa de aplicación (dominio)
- `infra/` - Adaptadores (handlers, repos)
- `observability/` - Telemetría y errores

---

## 🎓 **Recursos Adicionales**

- [SAM CLI Documentation](https://docs.aws.amazon.com/serverless-application-model/)
- [DynamoDB Local Guide](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DynamoDBLocal.html)
- [LocalStack Documentation](https://docs.localstack.cloud/)
- [Go AWS SDK v2](https://aws.github.io/aws-sdk-go-v2/docs/)

---

**¿Dudas o problemas?** 
- Revisa los logs: `docker compose logs -f`
- Verifica el estado: `make status`
- Intenta reconstruir: `make rebuild`
